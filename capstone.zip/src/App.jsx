import { useEffect, useState } from "react";
import { Routes, Route } from "react-router-dom";
import ListView from "./views/ListView";
import NewChoreView from "./views/NewChoreView";

export default function App() {
  const [chores, setChores] = useState(() => {
    const raw = localStorage.getItem("chores");
    return raw ? JSON.parse(raw) : [];
  });
  const [xp, setXp] = useState(() => {
    const raw = localStorage.getItem("xp");
    return raw ? JSON.parse(raw) : 0;
  });

  useEffect(() => {
    localStorage.setItem("chores", JSON.stringify(chores));
  }, [chores]);
  useEffect(() => {
    localStorage.setItem("xp", JSON.stringify(xp));
  }, [xp]);

  function addChore(title) {
    const t = title.trim();
    if (!t) return;
    setChores((prev) => [
      { id: crypto.randomUUID(), title: t, completed: false },
      ...prev,
    ]);
  }

  function toggleChore(id) {
    setChores((prev) => {
      const updated = prev.map((c) =>
        c.id === id ? { ...c, completed: !c.completed } : c,
      );

      const before = prev.find((c) => c.id === id);
      const after = updated.find((c) => c.id === id);

      if (before && after) {
        if (!before.completed && after.completed) {
          setXp((x) => x + 10);
        } else if (before.completed && !after.completed) {
          setXp((x) => Math.max(0, x - 10));
        }
      }

      return updated;
    });
  }

  function deleteChore(id) {
    setChores((prev) => prev.filter((c) => c.id !== id));
  }

  return (
    <Routes>
      <Route
        path="/"
        element={
          <ListView
            chores={chores}
            xp={xp}
            onToggle={toggleChore}
            onDelete={deleteChore}
          />
        }
      />
      <Route path="/new" element={<NewChoreView onAddChore={addChore} />} />
    </Routes>
  );
}
